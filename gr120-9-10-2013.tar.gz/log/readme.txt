floor
- unrounded controller
- 1, 5, 10, 30 VMs

individual
- individual bandwidth prioritized controller (0)

aggregate
- aggregate bandwidth prioritized controller (0)
- merged with floor 1, 5, 10, 30
  1, 2, 4, 5, 6, 8, 10, 12, 14, 16, 18, 20, 30 
- 2, 4, 6, 8, 12, 14, 16, 18, 20 

gridftp
- 1, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 30
- plotting graphs under /gridftp/detail/

