<html>
<head>

</head>
<title>rand-before</title>
<body>

<h2>WAN simulation rand-before (<a href=../>../UP</a>)</h2>

<a href=rand-before.png><img src=rand-before.png></a>
<a href=rand-before-detail.png><img src=rand-before-detail.png></a>
<a href=rand-before-before.png><img src=rand-before-before.png></a>
<a href=rand-before-net.png><img src=rand-before-net.png></a>
<br />

<a href=rand-before.eps>download rand-before.eps</a>, 
<a href=rand-before.emf>download rand-before.emf</a>
<a href=rand-before-before.eps>download rand-before-before.eps</a>
<a href=rand-before-net.eps>download rand-before-net.eps</a>
<br />
<a href=rand-before.tar>download all (rand-before.png, rand-before.dat, rand-before.p)</a>
<br />

<a href=rand-before.dat>rand-before.dat (data file)</a>
<?php
$str = file_get_contents("rand-before.dat");
echo "<pre>$str</pre>";
?>

<a href=rand-before.dstat>rand-before.dstat (network raw data file)</a>, 
<a href=rand-before-net.dat>rand-before-net.dat (network modified data file)</a>
<?php
$str = file_get_contents("rand-before.dstat");
echo "<pre>$str</pre>";
?>

<a href=rand-before.log>rand-before-r*.log (log files)</a>

<a href=rand-before.net>rand-before.net (dstat -cnm file)</a>
<?php
$str = file_get_contents("rand-before.net");
echo "<pre>$str</pre>";
?>

<br />

</body>
</html>

